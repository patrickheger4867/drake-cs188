const koa = require('koa');
const app = new koa();
import http from 'http'
const port =5555;

const {initCartControllers} = require('./controller/cart-controller');
const {initCustomerControllers} = require('./controller/customer-controller');
const {initItemControllers} = require('./controller/item-controller');
const {initCartItemControllers} = require('./controller/cart-item-controller');


const server = http.createServer(app.callback());

server.pre((req, res, next) => {
    console.info('%s - %s', req.method, req.url);
    return next();
});

server.use(koa.plugins.bodyParser({mapParams: true}));

initCartControllers(server);
initCustomerControllers(server);
initItemControllers(server);
initCartItemControllers(server);

server.listen(port, () => {
    console.info('%s listening on port %s', server.name, port);
});