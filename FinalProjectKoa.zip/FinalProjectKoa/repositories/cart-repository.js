let carts = [
    {
        'cart_id': 'mnbvcxza-1223-1234-3456-asdfghjk',
        'customer_id': 'd83dd143-agke-4r5a-8d1f-b91j5f0f9f28'
    },
    {
        'cart_id': 'alth858f-a02e-daa1-9ccf-dd3e2lohteb3',
        'customer_id': 'dasff143-9gfb-gf5a-hj8f-b9brhe0f9f28'
    }
];

const selectCarts = () => ({
    rows: carts,
});

const selectCartByCartId = (cartId) =>
    carts.find((cart) => cart['cart_id'] === cartId);

const selectCartsByCustomerId = (customerId) => ({
    rows: carts.filter((cart) => cart['customer_id'] === customerId)
});

const updateCart = (updatedCart) => {
    const cartsThatDontMatch = carts.filter((cart) =>
        cart['cart_id'] !== updatedCart['cart_id']
    );

    carts = [
        ...cartsThatDontMatch,
        updatedCart
    ];
};

const insertCart = (cart) => carts.push(cart);

const deleteCartByCartId = (cartId) => {
    carts = carts.filter((cart) => cart['cart_id'] !== cartId);
};

module.exports = {
    deleteCartByCartId,
    insertCart,
    selectCartByCartId,
    selectCarts,
    selectCartsByCustomerId,
    updateCart
};