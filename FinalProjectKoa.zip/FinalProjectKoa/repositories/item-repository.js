let items = [
    {
        'description': 'Drake Pants',
        'image': 'https://bkstr.scene7.com/is/image/Bkstr/6-33-QZ--H2-C-Black?$GMCategory_ET$',
        'item_id': 'lkjhgfds-erty-hgfd-cnvz-15467854"',
        'price': 30
    },

    {
        'description': 'Drake Sweatshirt',
        'image': 'https://m.media-amazon.com/images/I/615JDVNWE8L._SR500,500_.jpg',
        'item_id': 'g12rf24e-538s-as3a-lt5f-ptr4fe0fasd3',
        'price': 30
    }
];

const selectItems = () => ({
    rows: items
});

const selectItemByItemId = (itemId) =>
    items.find((item) => item['item_id'] === itemId);

const insertItem = (item) => items.push(item);

const updateItem = (updatedItem) => {
    const itemsThatDontMatch = items.filter((item) =>
        item['item_id'] !== updatedItem['item_id']
    );

    items = [
        ...itemsThatDontMatch,
        updatedItem
    ];
};

const deleteItemByItemId = (itemId) => {
    items = items.filter((item) =>
        item['item_id'] !== itemId
    );
};

module.exports = {
    deleteItemByItemId,
    insertItem,
    selectItemByItemId,
    selectItems,
    updateItem
};